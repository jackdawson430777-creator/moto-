package com.example.motohidepill;

import android.graphics.Canvas;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Suppresses only NavigationHandle.onDraw(), not the view itself.
 * Keeping the view attached and clickable is intended to preserve gesture handling.
 * Exact class names vary across Android/SystemUI builds, so several candidates are tried.
 */
public final class HidePillHook implements IXposedHookLoadPackage {
    private static final String TAG = "MotoHidePillLSPosed";
    private static final String SYSTEM_UI = "com.android.systemui";
    private static final String[] CANDIDATES = new String[] {
        "com.android.systemui.navigationbar.gestural.NavigationHandle",
        "com.android.systemui.navigationbar.NavigationHandle"
    };

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!SYSTEM_UI.equals(lpparam.packageName)) return;
        XposedBridge.log(TAG + ": loaded in SystemUI; looking for NavigationHandle");
        boolean hooked = false;
        for (String className : CANDIDATES) {
            try {
                Class<?> clazz = XposedHelpers.findClassIfExists(className, lpparam.classLoader);
                if (clazz == null) {
                    XposedBridge.log(TAG + ": class not found: " + className);
                    continue;
                }
                XposedHelpers.findAndHookMethod(clazz, "onDraw", Canvas.class, new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam param) {
                        // Skip painting the pill; do not hide/remove the view or alter touch callbacks.
                        param.setResult(null);
                    }
                });
                XposedBridge.log(TAG + ": hooked " + className + ".onDraw(Canvas)");
                hooked = true;
            } catch (Throwable t) {
                XposedBridge.log(TAG + ": failed to hook " + className + ": " + t);
            }
        }
        if (!hooked) XposedBridge.log(TAG + ": no known NavigationHandle class was hooked; check logs and report SystemUI class names");
    }
}
