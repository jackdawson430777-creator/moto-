# Moto Hide Pill — LSPosed project

Target device context: Moto G57 Power, Android 17, LSPosed. This is a source project intended to hide the gesture navigation pill while preserving the navigation handle view and its touch/long-press processing.

## What it does
- Hooks only `com.android.systemui` (SystemUI), not `com.motorola.launcher3`.
- Tries to hook `NavigationHandle.onDraw(Canvas)` and skips drawing. It deliberately does **not** set the view to `GONE`/`INVISIBLE`, remove it, or intercept touch events.
- This design is intended to keep the bottom gesture target available, which may preserve long-press Circle to Search. It is not yet verified on the user's exact Motorola SystemUI build; class names or drawing implementation may differ.

## Build on phone using GitHub Actions
1. Upload the *contents* of this project folder to the root of a GitHub repository (including the hidden `.github` folder). Do not upload only the ZIP.
2. Open Actions -> `Build Moto Hide Pill LSPosed APK` -> Run workflow.
3. Download artifact `MotoHidePill-LSPosed-debug`, extract `app-debug.apk`, install it.
4. In LSPosed enable the module and select scope **System UI / `com.android.systemui` only**.
5. Reboot, test that the pill is invisible and long-pressing the same bottom-center area still opens Circle to Search.

## Troubleshooting / recovery
- If the pill remains visible, check LSPosed logs for `MotoHidePillLSPosed` and whether a `NavigationHandle` class was hooked.
- If Circle to Search stops working, disable this module in LSPosed and reboot. The module does not change navigation settings or system partitions.
- If SystemUI crashes/restarts repeatedly, disable the module from LSPosed (safe mode/manager recovery if necessary).
